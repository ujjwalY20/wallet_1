module.exports.userValidation = require('./user.validation');
module.exports.walletValidation = require('./wallet.validation');